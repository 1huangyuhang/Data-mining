package com.fitness.analyzer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FitnessAnalyzerApplication {

	public static void main(String[] args) {
		SpringApplication.run(FitnessAnalyzerApplication.class, args);
	}

}
